const wordContainer = document.getElementById('wordContainer');
const startButton = document.getElementById('startButton');
const usedLettersElement = document.getElementById('usedLetters');
const keyboardContainer = document.getElementById('keyboard');
const livesDisplay = document.getElementById('lives-display');
const gameOverMessage = document.getElementById('game-over');
const wordReveal = document.getElementById('word-reveal');
const restartButton = document.getElementById('restart-button');

let canvas = document.getElementById('canvas');
let ctx = canvas.getContext('2d');
ctx.canvas.width = 0;
ctx.canvas.height = 0;

const bodyParts = [
    [4, 2, 1, 1], // Cabeza
    [4, 3, 1, 2], // Cuerpo
    [3, 3, 1, 1], // Brazo izquierdo
    [5, 3, 1, 1], // Brazo derecho
    [3, 5, 1, 1], // Pierna izquierda
    [5, 5, 1, 1]  // Pierna derecha
];

let selectedWord;
let usedLetters;
let mistakes;
let hits;
let lives = 7; 

const removeAccents = (str) => {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
};

const addLetter = (letter) => {
    const letterElement = document.createElement('span');
    letterElement.innerHTML = letter.toUpperCase();
    usedLettersElement.appendChild(letterElement);
};

const addBodyPart = (x, y, width, height) => {
    ctx.fillStyle = '#fff';
    ctx.fillRect(x, y, width, height);
};

const wrongLetter = () => {
    if (mistakes < bodyParts.length) {
        addBodyPart(...bodyParts[mistakes]);
    }
    mistakes++;
    lives--;
    updateLivesDisplay();

    if (lives === 0) { 
        endGame(`La palabra era: ${selectedWord.join('')}`); 
    }
};

const correctLetter = (letter) => {
    const { children } = wordContainer;
    for (let i = 0; i < children.length; i++) {
        if (removeAccents(children[i].innerHTML) === removeAccents(letter)) {
            children[i].classList.toggle('hidden');
            hits++;
        }
    }
    if (hits === selectedWord.length) endGame("Felicidades"); 
};

const letterInput = (letter) => {
    letter = letter.toUpperCase(); 
    const normalizedLetter = removeAccents(letter); 
    if (selectedWord.includes(normalizedLetter)) {
        correctLetter(normalizedLetter);
    } else {
        wrongLetter();
    }
    addLetter(letter);
    usedLetters.push(letter);
};

const letterEvent = (event) => {
    let newLetter = event.key.toUpperCase();
    if (newLetter.match(/^[a-zñ]$/i) && !usedLetters.includes(newLetter)) {
        letterInput(newLetter);
    }
};

const drawWord = () => {
    selectedWord.forEach((letter) => {
        const letterElement = document.createElement('span');
        letterElement.innerHTML = letter.toUpperCase();
        letterElement.classList.add('letter');
        letterElement.classList.add('hidden');
        wordContainer.appendChild(letterElement);
    });
};

const selectRandomWord = () => {
    let word = words[Math.floor(Math.random() * words.length)].toUpperCase();
    selectedWord = word.split('');
};

const drawHangMan = () => {
    ctx.canvas.width = 120;
    ctx.canvas.height = 160;
    ctx.scale(20, 20);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#d95d39';
    ctx.fillRect(0, 7, 4, 1);
    ctx.fillRect(1, 0, 1, 8);
    ctx.fillRect(2, 0, 3, 1);
    ctx.fillRect(4, 1, 1, 1);
};

const updateLivesDisplay = () => {
    if (livesDisplay) {
        livesDisplay.textContent = `Vidas restantes: ${lives}`;
    }
};

const generateKeyboard = () => {
    for (let i = 65; i <= 90; i++) {
        const letter = String.fromCharCode(i);
        const keyElement = document.createElement('button');
        keyElement.classList.add('key');
        keyElement.textContent = letter;
        keyboardContainer.appendChild(keyElement);
        keyElement.addEventListener('click', () => letterInput(letter));
    }
};

const endGame = (message) => {
    document.removeEventListener('keydown', letterEvent);
    gameOverMessage.textContent = message;
    gameOverMessage.classList.remove('hidden');
    restartButton.style.display = 'block';
};

const startGame = () => {
    usedLetters = [];
    mistakes = 0;
    hits = 0;
    lives = 7; 
    updateLivesDisplay();
    wordContainer.innerHTML = '';
    usedLettersElement.innerHTML = '';
    keyboardContainer.innerHTML = '';
    startButton.style.display = 'none';
    drawHangMan();
    selectRandomWord();
    drawWord();
    generateKeyboard();
    document.addEventListener('keydown', letterEvent);

    
    gameOverMessage.classList.add('hidden');
};

startButton.addEventListener('click', startGame);
updateLivesDisplay();

const words = [
    'Carne', 'Martillo', 'Lavadora', 'Sucio', 'Cangrejo', 'Lento', 'Alimentos', 'Delgado', 'Cubo', 'Comida',
    'Caracol', 'Abajo', 'Alumno', 'Bonito', 'Cesta', 'Sol', 'Beber', 'Botella', 'Hamburguesa', 'Invierno',
    'Manzana', 'Arcoiris', 'Avión', 'Bailar', 'Bicicleta', 'Burro', 'Cabeza', 'Cama', 'Canción', 'Chocolate',
    'Cielo', 'Coche', 'Computadora', 'Conejo', 'Dinosaurio', 'Elefante', 'Estrella', 'Familia', 'Fiesta',
    'Flor', 'Galleta', 'Gato', 'Guitarra', 'Helado', 'Helicóptero', 'Isla', 'Jirafa', 'Lápiz', 'León',
    'Libro', 'Luna', 'Maleta', 'Mariposa', 'Montaña', 'Naranja', 'Navidad', 'Nube', 'Osito', 'Pájaro',
    'Pantalón', 'Pelota', 'Perro', 'Pescado', 'Piano', 'Pirata', 'Plátano', 'Policía', 'Ratón', 'Reloj',
    'Robot', 'Serpiente', 'Sirena', 'Silla', 'Sombrero', 'Tigre', 'Tomate', 'Tortuga', 'Tren', 'Universo',
    'Vaca', 'Zanahoria', 'Zorro', 'Árbol', 'Elefante', 'Oso', 'Tiburón', 'Gorila', 'Delfín', 'Hipopótamo',
    'Cocodrilo', 'Pingüino', 'Jirafa', 'Cebra', 'Rinoceronte', 'Leopardo', 'Araña', 'Escorpión', 'Mosquito',
    'Murciélago', 'Cucaracha', 'Chimpancé', 'Puma', 'Kangaroo', 'Koala', 'Gorila', 'Panda', 'Avestruz',
    'Pavo', 'Pinguino', 'Orangután', 'Jaguar', 'Lince', 'Guepardo', 'Perezoso', 'Mandril', 'Halcón', 'Águila'
];

restartButton.addEventListener('click', () => {
    startGame();
    restartButton.style.display = 'none';
    wordReveal.textContent = '';
    gameOverMessage.classList.add('hidden');
});
